
class ShrinkageMethod:
    shrinkage_eye = "shrinkage_eye"
    shrinkage_diag = "shrinkage_diag"


