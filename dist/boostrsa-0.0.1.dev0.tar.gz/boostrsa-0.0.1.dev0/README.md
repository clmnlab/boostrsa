
# Boostrsa

blahblah

## Setup

### Dependencies

numba
cupy

### PIP

